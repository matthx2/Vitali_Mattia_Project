/**
 * Gestisce la lettura e la scrittura dell'oggetto Rubrica su file.
 * Utilizza la serializzazione Java per salvare e caricare l'intero stato
 * della rubrica in un file binario.
 */
package it.rubrica.service;

// Eccezione personalizzata per errori durante le operazioni su file.
import it.rubrica.eccezioni.FileNonValidoException;
// L'oggetto principale che viene salvato e caricato.
import it.rubrica.model.Rubrica;
// Fornisce le classi per la gestione di Input/Output su file e la serializzazione.
import java.io.*;

public class GestoreFile {

    /**
     * Legge un oggetto Rubrica da un file specificato.
     * 
     * @param filePath Il percorso del file da cui leggere.
     * @return L'oggetto Rubrica deserializzato.
     */
    public Rubrica leggi(String filePath) {
        // garantisce la chiusura automatica del file anche in caso di errori.
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            // Legge l'oggetto serializzato dal file e lo converte di nuovo in un
            // oggetto Rubrica.
            return (Rubrica) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // Cattura le eccezioni di I/O o classe non trovata,
            // e le rilancia come un'eccezione specifica dell'applicazione.
            throw new FileNonValidoException("Impossibile leggere il file della rubrica: " + e.getMessage());
        }
    }

    /**
     * Scrive un oggetto Rubrica su un file specificato.
     * 
     * @param rubrica  L'oggetto Rubrica da salvare.
     * @param filePath Il percorso del file su cui scrivere.
     */
    public void scrivi(Rubrica rubrica, String filePath) {
        // Assicura che il file venga chiuso correttamente.
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            // Serializza l'intero oggetto 'rubrica' e il suo stato, scrivendolo nel file.
            oos.writeObject(rubrica);
        } catch (IOException e) {
            throw new FileNonValidoException("Impossibile salvare il file della rubrica: " + e.getMessage());
        }
    }
}