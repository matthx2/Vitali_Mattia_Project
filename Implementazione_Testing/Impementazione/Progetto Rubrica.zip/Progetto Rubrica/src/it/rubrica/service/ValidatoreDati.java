/**
 * Fornisce metodi di servizio per la validazione dei dati dei contatti.
 * Centralizza le regole di business (es. formato email, obbligatorietà dei campi)
 * in un'unica classe per garantire coerenza e facilitare la manutenzione.
 */
package it.rubrica.service;

// Eccezione lanciata se un campo richiesto non è compilato.
import it.rubrica.eccezioni.CampoObbligatorioException;
// Eccezione lanciata se il formato di un dato non è valido (es. email, telefono).
import it.rubrica.eccezioni.FormatoDatiException;
// Eccezione lanciata se si viola un vincolo sul numero di elementi (es. max 3 telefoni).
import it.rubrica.eccezioni.VincoloQuantitaException;
// Utilizzato per validare collezioni di dati, come le liste di telefoni ed email.
import java.util.List;

public class ValidatoreDati {

    /**
     * Almeno uno tra nome e cognome deve
     * essere presente.
     * 
     * @param nome    Il nome da controllare.
     * @param cognome Il cognome da controllare.
     */
    public void validaNomeCognome(String nome, String cognome) {
        boolean nomeVuoto = (nome == null || nome.trim().isEmpty());
        boolean cognomeVuoto = (cognome == null || cognome.trim().isEmpty());

        // Lancia un'eccezione solo se entrambi i campi risultano vuoti.
        if (nomeVuoto && cognomeVuoto) {
            throw new CampoObbligatorioException("È obbligatorio compilare almeno il nome o il cognome.");
        }
    }

    /**
     * Valida il formato di un numero di telefono.
     * 
     * @param numero La stringa del numero da validare.
     */
    public void validaNumeroTelefono(String numero) {
        // Utilizza un'espressione regolare per verificare un formato telefonico
        // generico.
        // Accetta un prefisso '+' opzionale, seguito da 7 a 15 caratteri tra cifre,
        // spazi e trattini.
        if (!numero.matches("^\\+?[0-9\\s-]{7,15}$")) {
            throw new FormatoDatiException(
                    "Formato numero non valido: '" + numero + "'.\n" +
                            "Assicurati che contenga tra 7 e 15 cifre, opzionalmente con un prefisso '+'.");
        }
    }

    /**
     * Valida il formato di un indirizzo email.
     * 
     * @param email La stringa dell'email da validare.
     */
    public void validaEmail(String email) {
        // Utilizza un'espressione regolare per validare la struttura standard
        // di un'email.
        if (!email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$")) {
            throw new FormatoDatiException(
                    "Formato email non valido: '" + email + "'.\n" +
                            "L'email deve essere nel formato 'utente@dominio.it'.");
        }
    }

    /**
     * Controlla che il numero di elementi in una lista non superi il massimo
     * consentito.
     * 
     * @param lista La lista da controllare.
     * @param max   Il numero massimo di elementi permessi.
     */
    public void validaLista(List<?> lista, int max) {
        if (lista.size() > max) {
            throw new VincoloQuantitaException("È possibile inserire al massimo " + max + " elementi.");
        }
    }
}