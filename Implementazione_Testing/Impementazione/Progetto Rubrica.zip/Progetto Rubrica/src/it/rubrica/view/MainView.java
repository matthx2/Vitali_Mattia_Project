/**
 * Rappresenta la finestra principale (JFrame) dell'applicazione.
 * Assembla i pannelli secondari (ricerca, lista, strumenti) e orchestra
 * le interazioni tra la vista e il controller.
 */
package it.rubrica.view;

// Import per le classi dei componenti grafici di base.
import java.awt.*;
// Import per le classi dei componenti grafici Swing.
import javax.swing.*;
// Import per la classe Controller che gestisce la logica.
import it.rubrica.controller.RubricaController;
// Import per la classe Contatto (non più utilizzato direttamente in questa classe).
import it.rubrica.model.Contatto;

public class MainView extends JFrame {
    private final RubricaController controller;
    private final PanelListaContatti panelLista;
    private final Color royalBlue = new Color(65, 105, 225);
    private final Color buttonBackgroundColor = Color.WHITE;
    private final Color buttonTextColor = Color.BLACK;

    public MainView(RubricaController controller) {
        this.controller = controller;

        setTitle("Gestione Rubrica");
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(0, 0));
        getContentPane().setBackground(royalBlue);

        // --- COSTRUZIONE INTERFACCIA ---

        // Crea e posiziona il pannello di ricerca in alto.
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        searchPanel.setBackground(royalBlue);
        JLabel cercaLabel = new JLabel("Cerca:");
        cercaLabel.setForeground(Color.WHITE);
        searchPanel.add(cercaLabel);
        JTextField ricercaField = new JTextField(25);
        searchPanel.add(ricercaField);
        JButton ricercaBtn = new JButton("Cerca");
        ricercaBtn.setBackground(buttonBackgroundColor);
        ricercaBtn.setForeground(buttonTextColor);
        searchPanel.add(ricercaBtn);
        add(searchPanel, BorderLayout.NORTH);

        // Crea e posiziona il pannello che conterrà la lista dei contatti al centro.
        panelLista = new PanelListaContatti(this);
        panelLista.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        add(panelLista, BorderLayout.CENTER);

        // Crea e posiziona il pannello con i pulsanti di azione in basso.
        PanelStrumenti panelStrumenti = new PanelStrumenti(this);
        add(panelStrumenti, BorderLayout.SOUTH);

        // Collega gli eventi dei componenti alle azioni.
        ricercaBtn.addActionListener(e -> cercaContatti(ricercaField.getText()));
        ricercaField.addActionListener(e -> cercaContatti(ricercaField.getText()));

        // Carica la vista iniziale dei contatti.
        aggiornaVistaContatti(false);
    }

    /**
     * Chiede i contatti al controller e li passa al pannello della lista per la
     * visualizzazione.
     * * @param ordinati Se `true`, richiede la lista ordinata; altrimenti, in
     * ordine
     * di inserimento.
     */
    public void aggiornaVistaContatti(boolean ordinati) {
        try {
            panelLista.aggiornaLista(controller.getContatti(ordinati));
        } catch (Exception e) {
            mostraMessaggio("Errore durante l'aggiornamento: " + e.getMessage());
        }
    }

    /**
     * Esegue l'aggiornamento della vista richiedendo esplicitamente la lista
     * ordinata.
     */
    public void visualizzaRubricaOrdinata() {
        aggiornaVistaContatti(true);
    }

    /**
     * Apre la finestra di dialogo per creare un nuovo contatto e aggiorna la vista
     * se l'operazione ha successo.
     */
    public void creaNuovoContatto() {
        if (DialogoContatto.mostraPerCreazione(this, controller)) {
            aggiornaVistaContatti(false);
        }
    }

    /**
     * Gestisce la modifica di un contatto.
     * * @param contatto L'oggetto Contatto da modificare.
     */
    public void modificaContatto(Contatto contatto) {
        // Trova l'indice reale del contatto nel modello prima di aprire la finestra di
        // modifica.
        int index = controller.getIndiceContatto(contatto);
        if (index == -1) {
            mostraMessaggio("Errore: contatto non trovato.");
            return;
        }
        if (DialogoContatto.mostraPerModifica(this, controller, contatto, index)) {
            aggiornaVistaContatti(false);
        }
    }

    /**
     * Gestisce l'eliminazione di un contatto dopo conferma dell'utente.
     * * @param contatto L'oggetto Contatto da eliminare.
     */
    public void eliminaContatto(Contatto contatto) {
        int choice = JOptionPane.showConfirmDialog(this, "Sei sicuro di voler eliminare questo contatto?",
                "Conferma eliminazione", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            try {
                // Trova l'indice reale del contatto prima di inviare la richiesta di
                // eliminazione.
                int index = controller.getIndiceContatto(contatto);
                if (index != -1) {
                    controller.rimuoviContatto(index);
                    aggiornaVistaContatti(false);
                }
            } catch (Exception e) {
                mostraMessaggio("Errore eliminazione: " + e.getMessage());
            }
        }
    }

    /**
     * Filtra i contatti visualizzati in base a una stringa di ricerca.
     * * @param query Il testo da cercare nel nome o cognome.
     */
    public void cercaContatti(String query) {
        try {
            // Se la ricerca è vuota, ripristina la vista completa dei contatti.
            if (query.trim().isEmpty()) {
                aggiornaVistaContatti(false);
            } else {
                panelLista.aggiornaLista(controller.ricercaContatti(query));
            }
        } catch (Exception e) {
            mostraMessaggio("Errore ricerca: " + e.getMessage());
        }
    }

    /**
     * Apre una finestra di dialogo per permettere all'utente di salvare la rubrica
     * su file.
     */
    public void salvaRubrica() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Salva rubrica");
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                String path = fileChooser.getSelectedFile().getPath();
                if (!path.toLowerCase().endsWith(".dat"))
                    path += ".dat";
                controller.salvaRubrica(path);
                mostraMessaggio("Rubrica salvata con successo.");
            } catch (Exception e) {
                mostraMessaggio("Salvataggio fallito: " + e.getMessage());
            }
        }
    }

    /**
     * Apre una finestra di dialogo per permettere all'utente di caricare una
     * rubrica da file.
     */
    public void caricaRubrica() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Carica rubrica");
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                controller.caricaRubrica(fileChooser.getSelectedFile().getPath());
                aggiornaVistaContatti(false);
                mostraMessaggio("Rubrica caricata con successo.");
            } catch (Exception e) {
                mostraMessaggio("Caricamento fallito: " + e.getMessage());
            }
        }
    }

    /**
     * Mostra un semplice messaggio informativo all'utente.
     * * @param messaggio Il testo da visualizzare.
     */
    public void mostraMessaggio(String messaggio) {
        JOptionPane.showMessageDialog(this, messaggio);
    }

    // I metodi deprecati modificaContattoSelezionato ed eliminaContattoSelezionato
    // sono stati rimossi in quanto obsoleti e non più utilizzati.
}