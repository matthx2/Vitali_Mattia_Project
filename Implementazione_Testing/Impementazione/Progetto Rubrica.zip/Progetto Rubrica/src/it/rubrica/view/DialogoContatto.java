/**
 * Rappresenta la finestra di dialogo (JDialog) per l'inserimento e la modifica
 * dei dati di un singolo contatto. Gestisce dinamicamente i campi per telefoni ed email.
 */
package it.rubrica.view;

// Import per le classi dei componenti grafici di base.
import java.awt.*;
// Import per le classi dei componenti grafici Swing.
import javax.swing.*;
// Import per la gestione di collezioni di dati.
import java.util.ArrayList;
import java.util.List;
// Import per le classi del modello e del controller.
import it.rubrica.controller.RubricaController;
import it.rubrica.model.Contatto;

public class DialogoContatto extends JDialog {
    private final JTextField nomeField, cognomeField;
    private final List<JTextField> telefoniFields;
    private final List<JTextField> emailFields;
    private final JPanel telefoniPanel;
    private final JPanel emailPanel;
    private final JButton aggiungiTelefonoBtn;
    private final JButton aggiungiEmailBtn;
    private final RubricaController controller;
    private final Contatto contattoOriginale;
    private final int indiceContatto;
    private boolean confermato;

    /**
     * Costruttore del dialogo. Imposta l'interfaccia grafica e la logica interna.
     */
    public DialogoContatto(Frame owner, String title, RubricaController controller, Contatto contattoToEdit,
            int indice) {
        super(owner, title, true);
        this.controller = controller;
        this.contattoOriginale = contattoToEdit;
        this.indiceContatto = indice;
        this.confermato = false;

        this.telefoniFields = new ArrayList<>();
        this.emailFields = new ArrayList<>();

        // IMPOSTAZIONE STILE E LAYOUT 
        Color royalBlue = new Color(65, 105, 225);
        Color labelColor = Color.WHITE;
        setLayout(new BorderLayout(10, 10));
        setMinimumSize(new Dimension(500, 400));
        getContentPane().setBackground(royalBlue);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(royalBlue);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        nomeField = new JTextField(30);
        styleTextField(nomeField);
        cognomeField = new JTextField(30);
        styleTextField(cognomeField);

        telefoniPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        telefoniPanel.setOpaque(false);
        emailPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        emailPanel.setOpaque(false);

        aggiungiTelefonoBtn = new JButton("Aggiungi Numero");
        aggiungiEmailBtn = new JButton("Aggiungi Email");

        // Creazione, stile e aggiunta delle etichette in passaggi separati
        JLabel nomeLabel = new JLabel("Nome:");
        nomeLabel.setForeground(labelColor);
        JLabel cognomeLabel = new JLabel("Cognome:");
        cognomeLabel.setForeground(labelColor);
        JLabel telefoniLabel = new JLabel("Telefoni:");
        telefoniLabel.setForeground(labelColor);
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(labelColor);

        // Disposizione dei componenti nella griglia.
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.weightx = 0.0;
        formPanel.add(nomeLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        formPanel.add(nomeField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.weightx = 0.0;
        formPanel.add(cognomeLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        formPanel.add(cognomeField, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        gbc.weightx = 0.0;
        formPanel.add(telefoniLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        formPanel.add(telefoniPanel, gbc);

        gbc.gridy++;
        gbc.gridx = 1;
        formPanel.add(aggiungiTelefonoBtn, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        gbc.weightx = 0.0;
        formPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        formPanel.add(emailPanel, gbc);

        gbc.gridy++;
        gbc.gridx = 1;
        formPanel.add(aggiungiEmailBtn, gbc);

        if (contattoOriginale != null) {
            nomeField.setText(contattoOriginale.getNome());
            cognomeField.setText(contattoOriginale.getCognome());
            contattoOriginale.getTelefoni().forEach(this::aggiungiNuovoCampoTelefono);
            contattoOriginale.getEmail().forEach(this::aggiungiNuovoCampoEmail);
        }

        if (telefoniFields.isEmpty())
            aggiungiNuovoCampoTelefono(null);
        if (emailFields.isEmpty())
            aggiungiNuovoCampoEmail(null);

        aggiungiTelefonoBtn.addActionListener(e -> aggiungiNuovoCampoTelefono(null));
        aggiungiEmailBtn.addActionListener(e -> aggiungiNuovoCampoEmail(null));

        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Annulla");
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        okButton.addActionListener(e -> onOK());
        cancelButton.addActionListener(e -> dispose());

        add(new JScrollPane(formPanel), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);
    }

    private void styleTextField(JTextField field) {
        field.setBackground(Color.WHITE);
        field.setForeground(Color.BLACK);
    }

    private void aggiungiNuovoCampoTelefono(String testo) {
        if (!telefoniFields.isEmpty() && telefoniFields.get(telefoniFields.size() - 1).getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Compila il campo precedente prima di aggiungerne un altro.",
                    "Campo Vuoto", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (telefoniFields.size() >= 3) {
            JOptionPane.showMessageDialog(this, "Puoi inserire al massimo 3 numeri di telefono.", "Limite Raggiunto",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        JTextField nuovoCampo = new JTextField(30);
        styleTextField(nuovoCampo);
        if (testo != null)
            nuovoCampo.setText(testo);
        telefoniFields.add(nuovoCampo);
        telefoniPanel.add(nuovoCampo);
        telefoniPanel.revalidate();
        telefoniPanel.repaint();
        pack();
        if (telefoniFields.size() == 3)
            aggiungiTelefonoBtn.setEnabled(false);
    }

    private void aggiungiNuovoCampoEmail(String testo) {
        if (!emailFields.isEmpty() && emailFields.get(emailFields.size() - 1).getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Compila il campo precedente prima di aggiungerne un altro.",
                    "Campo Vuoto", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (emailFields.size() >= 3) {
            JOptionPane.showMessageDialog(this, "Puoi inserire al massimo 3 indirizzi email.", "Limite Raggiunto",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        JTextField nuovoCampo = new JTextField(30);
        styleTextField(nuovoCampo);
        if (testo != null)
            nuovoCampo.setText(testo);
        emailFields.add(nuovoCampo);
        emailPanel.add(nuovoCampo);
        emailPanel.revalidate();
        emailPanel.repaint();
        pack();
        if (emailFields.size() == 3)
            aggiungiEmailBtn.setEnabled(false);
    }

    private void onOK() {
        String nome = nomeField.getText();
        String cognome = cognomeField.getText();

        List<String> telefoni = new ArrayList<>();
        for (JTextField field : telefoniFields) {
            String testo = field.getText().trim();
            if (!testo.isEmpty())
                telefoni.add(testo);
        }

        List<String> emails = new ArrayList<>();
        for (JTextField field : emailFields) {
            String testo = field.getText().trim();
            if (!testo.isEmpty())
                emails.add(testo);
        }

        try {
            if (contattoOriginale == null) {
                controller.creaContatto(nome, cognome, telefoni, emails);
            } else {
                controller.aggiornaContatto(indiceContatto, nome, cognome, telefoni, emails);
            }
            confermato = true;
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Errore di Validazione", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isConfermato() {
        return confermato;
    }

    public static boolean mostraPerCreazione(Frame owner, RubricaController controller) {
        DialogoContatto dialog = new DialogoContatto(owner, "Nuovo Contatto", controller, null, -1);
        dialog.setVisible(true);
        return dialog.isConfermato();
    }

    public static boolean mostraPerModifica(Frame owner, RubricaController controller, Contatto contatto, int indice) {
        DialogoContatto dialog = new DialogoContatto(owner, "Modifica Contatto", controller, contatto, indice);
        dialog.setVisible(true);
        return dialog.isConfermato();
    }
}