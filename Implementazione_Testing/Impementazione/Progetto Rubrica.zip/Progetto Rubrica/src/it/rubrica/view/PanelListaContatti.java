/**
 * Rappresenta il pannello centrale dell'interfaccia, responsabile della visualizzazione
 * della lista dei contatti. Gestisce due stati: la visualizzazione delle "schede" dei contatti
 * e un messaggio centrato quando la rubrica è vuota.
 */
package it.rubrica.view;

// Import per le classi dei componenti grafici di base.
import java.awt.*;
// Import per le classi dei componenti grafici Swing.
import javax.swing.*;
// Import per creare bordi e spaziature.
import javax.swing.border.EmptyBorder;
// Import per la gestione di collezioni di dati, come la lista di contatti.
import java.util.List;
// Import per la classe che rappresenta il singolo contatto.
import it.rubrica.model.Contatto;

public class PanelListaContatti extends JPanel {
    private final MainView mainView;
    private final JPanel cardsContainer;
    private final JPanel mainCardPanel;
    private final CardLayout cardLayout;

    // Costanti per identificare i due pannelli (viste) gestiti dal CardLayout.
    private static final String LIST_VIEW = "ListView";
    private static final String EMPTY_VIEW = "EmptyView";

    /**
     * Costruttore del pannello che visualizza i contatti.
     * 
     * @param mainView Il riferimento alla finestra principale.
     */
    public PanelListaContatti(MainView mainView) {
        this.mainView = mainView;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        cardLayout = new CardLayout();
        mainCardPanel = new JPanel(cardLayout);

        cardsContainer = new JPanel();
        cardsContainer.setLayout(new BoxLayout(cardsContainer, BoxLayout.Y_AXIS));
        cardsContainer.setBackground(Color.WHITE);

        JPanel wrapperPanel = new JPanel(new BorderLayout());
        wrapperPanel.setBackground(Color.WHITE);
        wrapperPanel.add(cardsContainer, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane(wrapperPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);

        JPanel emptyPanel = new JPanel(new GridBagLayout());
        emptyPanel.setBackground(Color.WHITE);
        JLabel emptyLabel = new JLabel("La rubrica è vuota.");
        emptyLabel.setFont(new Font("Verdana", Font.ITALIC, 18));
        emptyLabel.setForeground(Color.GRAY);
        emptyPanel.add(emptyLabel);

        mainCardPanel.add(scrollPane, LIST_VIEW);
        mainCardPanel.add(emptyPanel, EMPTY_VIEW);

        add(mainCardPanel, BorderLayout.CENTER);
    }

    private JTextArea createWrappingTextArea(String text) {
        JTextArea textArea = new JTextArea(text);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setOpaque(false);
        textArea.setEditable(false);
        textArea.setFocusable(false);
        textArea.setFont(UIManager.getFont("Label.font"));
        textArea.setForeground(Color.BLACK);
        textArea.setBorder(null);
        return textArea;
    }

    /**
     * @param contatto L'oggetto Contatto da visualizzare.
     * @return Un JPanel che rappresenta la scheda del contatto.
     */
    private JPanel createContactCardPanel(Contatto contatto) {
        JPanel card = new JPanel(new BorderLayout(15, 5)); 
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1, true),
                new EmptyBorder(10, 15, 10, 15)));
        card.setBackground(Color.WHITE);

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBackground(Color.WHITE);

        JLabel nomeLabel = new JLabel(contatto.getNome() + " " + contatto.getCognome());
        nomeLabel.setFont(new Font("Verdana", Font.BOLD, 18));
        infoPanel.add(nomeLabel);

        infoPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        if (!contatto.getTelefoni().isEmpty()) {
            infoPanel.add(createWrappingTextArea("Telefoni: " + String.join(", ", contatto.getTelefoni())));
        }
        if (!contatto.getEmail().isEmpty()) {
            infoPanel.add(Box.createRigidArea(new Dimension(0, 4)));
            infoPanel.add(createWrappingTextArea("Email: " + String.join(", ", contatto.getEmail())));
        }
        card.add(infoPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(Color.WHITE);

        JButton modificaBtn = new JButton("Modifica");
        modificaBtn.addActionListener(e -> mainView.modificaContatto(contatto));

        JButton eliminaBtn = new JButton("Elimina");
        eliminaBtn.addActionListener(e -> mainView.eliminaContatto(contatto));

        modificaBtn.setAlignmentX(Component.RIGHT_ALIGNMENT);
        eliminaBtn.setAlignmentX(Component.RIGHT_ALIGNMENT);

        buttonPanel.add(modificaBtn);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 5))); 
        buttonPanel.add(eliminaBtn);

        card.add(buttonPanel, BorderLayout.EAST);

        // Impedisce alla card di espandersi in altezza oltre la sua dimensione
        // preferita.
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, card.getPreferredSize().height));

        return card;
    }

    /**
     * @param contatti La lista di contatti da visualizzare.
     */
    public void aggiornaLista(List<Contatto> contatti) {
        cardsContainer.removeAll();
        if (contatti == null || contatti.isEmpty()) {
            cardLayout.show(mainCardPanel, EMPTY_VIEW);
        } else {
            for (Contatto c : contatti) {
                cardsContainer.add(createContactCardPanel(c));
                cardsContainer.add(Box.createRigidArea(new Dimension(0, 10)));
            }
            cardsContainer.add(Box.createVerticalGlue());
            cardLayout.show(mainCardPanel, LIST_VIEW);
        }
        revalidate();
        repaint();
    }
}