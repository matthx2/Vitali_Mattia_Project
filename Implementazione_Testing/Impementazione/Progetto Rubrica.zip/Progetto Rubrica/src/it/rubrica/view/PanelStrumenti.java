/**
 * Rappresenta il pannello inferiore dell'interfaccia (la barra degli strumenti principale),
 * contenente i pulsanti per le azioni globali sulla rubrica come Aggiungi, Ordina, Carica e Salva.
 */
package it.rubrica.view;

// Fornisce le classi base per i componenti dell'interfaccia utente come JPanel e JButton.
import javax.swing.*;
// Fornisce le classi per la gestione del layout (GridLayout) e dei colori (Color).
import java.awt.*;

public class PanelStrumenti extends JPanel {

    /**
     * Costruttore del pannello degli strumenti.
     * 
     * @param mainView Il riferimento alla finestra principale per poter richiamare
     *                 i suoi metodi.
     */
    public PanelStrumenti(MainView mainView) {
        // Layout a griglia con 1 riga e 4 colonne.
        // I 4 pulsanti occupano lo stesso spazio e si adattano alla
        // larghezza della finestra.
        setLayout(new GridLayout(1, 4, 10, 10));

        // Lo stile del pannello.
        Color royalBlue = new Color(65, 105, 225);
        setBackground(royalBlue);
        setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));

        // I pulsanti per le azioni principali.
        JButton aggiungiBtn = new JButton("Aggiungi Contatto");
        JButton ordinaBtn = new JButton("Visualizza Rubrica Ordinata");
        JButton caricaBtn = new JButton("Carica Rubrica");
        JButton salvaBtn = new JButton("Salva Rubrica");

        for (JButton btn : new JButton[] { aggiungiBtn, ordinaBtn, caricaBtn, salvaBtn }) {
            btn.setBackground(Color.WHITE);
            btn.setForeground(Color.BLACK);
            add(btn);
        }

        // Collega l'evento "click" di ogni pulsante a un metodo pubblico della finestra
        // principale MainView.
        aggiungiBtn.addActionListener(e -> mainView.creaNuovoContatto());
        ordinaBtn.addActionListener(e -> mainView.visualizzaRubricaOrdinata());
        caricaBtn.addActionListener(e -> mainView.caricaRubrica());
        salvaBtn.addActionListener(e -> mainView.salvaRubrica());
    }
}