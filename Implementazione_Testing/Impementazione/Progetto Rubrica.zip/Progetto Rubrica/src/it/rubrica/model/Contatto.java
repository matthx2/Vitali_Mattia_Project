/**
 * Modella un singolo contatto della rubrica.
 * Contiene i dati anagrafici (nome, cognome) e le liste di recapiti (telefoni, email).
 * È una classe che implementa Serializable per consentire il salvataggio su file.
 */
package it.rubrica.model;

// Interfaccia marcatore che indica che gli oggetti di questa classe possono essere serializzati.
import java.io.Serializable;
// Classi per la gestione di collezioni di dati.
import java.util.ArrayList;
import java.util.List;
// Classe di utilità per implementare i metodi equals() e hashCode() in modo sicuro e robusto.
import java.util.Objects;

public class Contatto implements Serializable {
    // Identificativo univoco per la serializzazione.
    private static final long serialVersionUID = 1L;

    private String nome;
    private String cognome;
    private final List<String> telefoni;
    private final List<String> email;

    public Contatto(String nome, String cognome) {
        this.nome = nome;
        this.cognome = cognome;
        // Inizializza le liste con una capacità iniziale di 3.
        this.telefoni = new ArrayList<>(3);
        this.email = new ArrayList<>(3);
    }

    // Metodi Getter e Setter 

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    /**
     * Restituisce una NUOVA lista contenente i telefoni.
     */
    public List<String> getTelefoni() {
        return new ArrayList<>(telefoni);
    }

    /**
     * Restituisce una NUOVA lista contenente le email.
     */
    public List<String> getEmail() {
        return new ArrayList<>(email);
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    // Metodi per la gestione delle liste.

    public void aggiungiTelefono(String numero) {
        if (telefoni.size() < 3) {
            telefoni.add(numero);
        }
    }

    public void rimuoviTelefono(String numero) {
        telefoni.remove(numero);
    }

    public void aggiungiEmail(String indirizzo) {
        if (email.size() < 3) {
            email.add(indirizzo);
        }
    }

    public void rimuoviEmail(String indirizzo) {
        email.remove(indirizzo);
    }

    /**
     * Controlla la validità del contatto, verificando che almeno il nome o il
     * cognome sia presente.
     * 
     * @return `true` se il contatto è valido, altrimenti `false`.
     */
    public boolean valida() {
        boolean nomeValido = (nome != null && !nome.trim().isEmpty());
        boolean cognomeValido = (cognome != null && !cognome.trim().isEmpty());
        return nomeValido || cognomeValido;
    }


    @Override
    public String toString() {
        return (nome.trim() + " " + cognome.trim()).trim();
    }

    /**
     * Override dei metodi equals e hashCode.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Contatto contatto = (Contatto) o;
        return Objects.equals(nome, contatto.nome) &&
                Objects.equals(cognome, contatto.cognome) &&
                Objects.equals(telefoni, contatto.telefoni) &&
                Objects.equals(email, contatto.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, cognome, telefoni, email);
    }
}