/**
 * Rappresenta l'intera rubrica, ovvero la collezione di tutti i contatti.
 * Questa classe agisce come modello (Model) principale dell'applicazione, gestendo
 * l'aggiunta, la modifica, l'eliminazione e la ricerca dei contatti.
 * Implementa Serializable per poter essere salvata su file.
 */
package it.rubrica.model;

// Eccezione per quando un contatto cercato tramite indice non esiste.
import it.rubrica.eccezioni.ContattoNonTrovatoException;
// Interfaccia che permette a un oggetto di essere convertito in un flusso di byte per il salvataggio.
import java.io.Serializable;
// Classi per la gestione di collezioni di dati.
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
// Usato insieme agli Stream per raccogliere i risultati in una nuova lista.
import java.util.stream.Collectors;

public class Rubrica implements Serializable {
    // Identificativo univoco per la serializzazione
    private static final long serialVersionUID = 1L;
    private final List<Contatto> contatti;

    public Rubrica() {
        this.contatti = new ArrayList<>();
    }

    public void aggiungiContatto(Contatto contatto) {
        contatti.add(contatto);
    }

    public void modificaContatto(int id, Contatto nuovoContatto) {
        if (id >= 0 && id < contatti.size()) {
            contatti.set(id, nuovoContatto);
        } else {
            throw new ContattoNonTrovatoException("Contatto non trovato all'indice: " + id);
        }
    }

    public void eliminaContatto(int id) {
        if (id >= 0 && id < contatti.size()) {
            contatti.remove(id);
        } else {
            throw new ContattoNonTrovatoException("Contatto non trovato all'indice: " + id);
        }
    }

    public Contatto getContatto(int id) {
        if (id >= 0 && id < contatti.size()) {
            return contatti.get(id);
        }
        throw new ContattoNonTrovatoException("Contatto non trovato all'indice: " + id);
    }


    public List<Contatto> getContatti() {
        return new ArrayList<>(contatti);
    }

    /**
     * @return Una lista di contatti ordinata per cognome e poi per nome.
     */
    public List<Contatto> getContattiOrdinati() {
        return contatti.stream()
                // Ordina prima per cognome e, in caso di omonimia, per nome.
                .sorted(Comparator.comparing(Contatto::getCognome).thenComparing(Contatto::getNome))
                .collect(Collectors.toList());
    }

    /**
     * @param sottostringa Il testo da cercare nel nome o cognome.
     * @return Una nuova lista contenente solo i contatti che corrispondono alla
     *         ricerca.
     */
    public List<Contatto> cercaContatti(String sottostringa) {
        String lowerCaseFilter = sottostringa.toLowerCase();
        return contatti.stream()
                .filter(c -> c.getNome().toLowerCase().contains(lowerCaseFilter) ||
                        c.getCognome().toLowerCase().contains(lowerCaseFilter))
                .collect(Collectors.toList());
    }

    public boolean isVuota() {
        return contatti.isEmpty();
    }

    public void aggiungiContatti(List<Contatto> nuoviContatti) {
        if (nuoviContatti != null) {
            this.contatti.addAll(nuoviContatti);
        }
    }

    /**
     * @param contatto L'oggetto Contatto da trovare.
     * @return L'indice del contatto, o -1 se non trovato.
     */
    public int getIndiceContatto(Contatto contatto) {
        return this.contatti.indexOf(contatto);
    }
}