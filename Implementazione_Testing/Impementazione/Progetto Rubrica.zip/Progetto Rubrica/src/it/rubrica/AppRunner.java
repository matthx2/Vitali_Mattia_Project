/**
 * Classe principale che rappresenta il punto di avvio dell'applicazione Rubrica.
 * Si occupa di impostare l'aspetto grafico globale 
 * e di inizializzare il pattern MVC (Model-View-Controller) creando la vista e il controller.
 */
package it.rubrica;

// Import per le classi di base della Grafica (Abstract Window Toolkit).
import java.awt.*;
// Import per le classi dei componenti grafici avanzati di Swing.
import javax.swing.*;
// Import per la classe Controller che gestisce tutta la logica.
import it.rubrica.controller.RubricaController;
// Import per la classe MainView che rappresenta la finestra principale.
import it.rubrica.view.MainView;

public class AppRunner {

   
    public static void main(String[] args) {
        try {
            // L'aspetto dell'applicazione in modo che corrisponda a quello del
            // sistema operativo
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            // Font di default in tutta l'applicazione.
            Font defaultFont = new Font("Verdana", Font.PLAIN, 13);

            // Font definito a tutti i tipi di componenti Swing (bottoni,
            // etichette, etc.).
            setUIFont(new javax.swing.plaf.FontUIResource(defaultFont));

        } catch (Exception e) {
            System.err.println("Impossibile impostare il Look and Feel o il font: " + e.getMessage());
        }

        SwingUtilities.invokeLater(() -> {
            RubricaController controller = new RubricaController();
            MainView view = new MainView(controller);
            view.setVisible(true);
        });
    }

    /**
     * @param f Il font da applicare.
     */
    public static void setUIFont(javax.swing.plaf.FontUIResource f) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof javax.swing.plaf.FontUIResource) {
                UIManager.put(key, f);
            }
        }
    }
}