package it.rubrica.eccezioni;

public class RubricaVuotaException extends RuntimeException {
    public RubricaVuotaException() {
        super();
    }

    public RubricaVuotaException(String messaggio) {
        super(messaggio);
    }
}