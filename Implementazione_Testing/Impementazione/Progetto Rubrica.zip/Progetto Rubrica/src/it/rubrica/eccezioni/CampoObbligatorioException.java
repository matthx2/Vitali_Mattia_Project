package it.rubrica.eccezioni;

public class CampoObbligatorioException extends RuntimeException {
    public CampoObbligatorioException() {
        super();
    }

    public CampoObbligatorioException(String messaggio) {
        super(messaggio);
    }
}
