package it.rubrica.eccezioni;

public class FormatoDatiException extends RuntimeException {
    public FormatoDatiException() {
        super();
    }

    public FormatoDatiException(String messaggio) {
        super(messaggio);
    }
}