package it.rubrica.eccezioni;

public class VincoloQuantitaException extends RuntimeException {
    public VincoloQuantitaException() {
        super();
    }

    public VincoloQuantitaException(String messaggio) {
        super(messaggio);
    }
}