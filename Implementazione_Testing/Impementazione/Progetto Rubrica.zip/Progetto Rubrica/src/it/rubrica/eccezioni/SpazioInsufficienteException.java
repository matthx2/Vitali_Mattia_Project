package it.rubrica.eccezioni;

public class SpazioInsufficienteException extends RuntimeException {
    public SpazioInsufficienteException() {
        super();
    }

    public SpazioInsufficienteException(String messaggio) {
        super(messaggio);
    }
}