package it.rubrica.eccezioni;

public class FileNonValidoException extends RuntimeException {
    public FileNonValidoException() {
        super();
    }

    public FileNonValidoException(String messaggio) {
        super(messaggio);
    }
}