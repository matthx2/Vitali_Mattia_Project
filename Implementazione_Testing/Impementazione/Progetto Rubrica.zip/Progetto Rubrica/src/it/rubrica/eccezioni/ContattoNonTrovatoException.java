package it.rubrica.eccezioni;

public class ContattoNonTrovatoException extends RuntimeException {
    public ContattoNonTrovatoException() {
        super();
    }

    public ContattoNonTrovatoException(String messaggio) {
        super(messaggio);
    }
}