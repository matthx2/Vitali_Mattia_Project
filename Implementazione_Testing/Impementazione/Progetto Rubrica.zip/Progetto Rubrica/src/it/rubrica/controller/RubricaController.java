/**
 * Agisce come Controller nel pattern MVC (Model-View-Controller).
 * Fa da mediatore tra l'interfaccia utente (la View) e i dati (il Model),
 * orchestrando le operazioni di validazione, salvataggio, caricamento e modifica dei contatti.
 */
package it.rubrica.controller;

// Eccezioni e classi del modello e dei servizi.
import it.rubrica.eccezioni.RubricaVuotaException;
import it.rubrica.model.Contatto;
import it.rubrica.model.Rubrica;
import it.rubrica.service.GestoreFile;
import it.rubrica.service.ValidatoreDati;
// Interfaccia per la gestione delle liste di contatti.
import java.util.List;

public class RubricaController {
    private Rubrica rubrica;
    private final ValidatoreDati validatore;
    private final GestoreFile gestoreFile;

    /**
     * Costruttore che inizializza il modello Rubrica e i servizi necessari.
     */
    public RubricaController() {
        this.rubrica = new Rubrica();
        this.validatore = new ValidatoreDati();
        this.gestoreFile = new GestoreFile();
    }

    /**
     * Creazione di un nuovo contatto.
     * Valida i dati e, se corretti, li passa al modello per l'aggiunta.
     */
    public void creaContatto(String nome, String cognome, List<String> telefoni, List<String> email) {
        // Validazione su tutti i campi prima di procedere.
        validatore.validaNomeCognome(nome, cognome);
        telefoni.forEach(validatore::validaNumeroTelefono);
        email.forEach(validatore::validaEmail);
        validatore.validaLista(telefoni, 3);
        validatore.validaLista(email, 3);

        Contatto nuovo = new Contatto(nome, cognome);
        telefoni.forEach(nuovo::aggiungiTelefono);
        email.forEach(nuovo::aggiungiEmail);

        rubrica.aggiungiContatto(nuovo);
    }

    /**
     * Modifica di un contatto esistente.
     */
    public void aggiornaContatto(int indice, String nome, String cognome, List<String> telefoni, List<String> email) {
        validatore.validaNomeCognome(nome, cognome);
        telefoni.forEach(validatore::validaNumeroTelefono);
        email.forEach(validatore::validaEmail);
        validatore.validaLista(telefoni, 3);
        validatore.validaLista(email, 3);

        Contatto aggiornato = new Contatto(nome, cognome);
        telefoni.forEach(aggiornato::aggiungiTelefono);
        email.forEach(aggiornato::aggiungiEmail);

        rubrica.modificaContatto(indice, aggiornato);
    }

    /**
     * Delega al modello l'eliminazione di un contatto.
     */
    public void rimuoviContatto(int indice) {
        rubrica.eliminaContatto(indice);
    }

    /**
     * Gestisce il salvataggio della rubrica su file.
     */
    public void salvaRubrica(String filePath) {
        // Impedisce di salvare una rubrica vuota.
        if (rubrica.isVuota()) {
            throw new RubricaVuotaException("Impossibile salvare una rubrica vuota.");
        }
        gestoreFile.scrivi(rubrica, filePath);
    }

    /**
     * Gestisce il caricamento, unendo i contatti del file a quelli esistenti.
     */
    public void caricaRubrica(String filePath) {
        Rubrica rubricaCaricata = gestoreFile.leggi(filePath);
        rubrica.aggiungiContatti(rubricaCaricata.getContatti());
    }

    /**
     * Delega al modello il recupero della lista di contatti (ordinata o meno).
     */
    public List<Contatto> getContatti(boolean ordinati) {
        return ordinati ? rubrica.getContattiOrdinati() : rubrica.getContatti();
    }

    /**
     * Delega al modello la ricerca dei contatti.
     */
    public List<Contatto> ricercaContatti(String sottostringa) {
        return rubrica.cercaContatti(sottostringa);
    }

    /**
     * Delega al modello il recupero di un singolo contatto tramite indice.
     */
    public Contatto getContatto(int index) {
        return rubrica.getContatto(index);
    }

    /**
     * Delega al modello la ricerca dell'indice di un oggetto Contatto.
     */
    public int getIndiceContatto(Contatto contatto) {
        return rubrica.getIndiceContatto(contatto);
    }
}